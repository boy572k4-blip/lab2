#!/bin/bash
service ssh start 2>/dev/null

# Tạo .seed cho Labtainer grader
mkdir -p /home/ubuntu/.local
echo "steg_dct-jpeg_seed" > /home/ubuntu/.local/.seed
echo "student@labtainer.local" > /home/ubuntu/.local/.email
echo "steg_dct-jpeg" > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

# Tạo /var/labtainer/did_param
mkdir -p /var/labtainer
touch /var/labtainer/did_param

mkdir -p /home/ubuntu/dct_lab
chown -R ubuntu:ubuntu /home/ubuntu/dct_lab

tail -f /dev/null
