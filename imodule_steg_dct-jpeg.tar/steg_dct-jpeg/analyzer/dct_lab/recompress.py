#!/usr/bin/env python3
"""Nén lại ảnh JPEG với chất lượng khác nhau để kiểm tra Recompression Attack"""
import argparse
from PIL import Image
import os


def recompress(input_path, output_path, quality):
    img = Image.open(input_path).convert('RGB')
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    img.save(output_path, 'JPEG', quality=quality)
    orig_size  = os.path.getsize(input_path)
    new_size   = os.path.getsize(output_path)
    print(f"[RECOMPRESS] {input_path} → {output_path}")
    print(f"  Chất lượng : {quality}")
    print(f"  Kích thước gốc  : {orig_size} bytes")
    print(f"  Kích thước mới  : {new_size} bytes")
    print(f"  [INFO] Hệ số DCT đã bị thay đổi hoàn toàn sau recompression.")


def main():
    parser = argparse.ArgumentParser(description='Recompress JPEG')
    parser.add_argument('--input',   required=True)
    parser.add_argument('--output',  required=True)
    parser.add_argument('--quality', type=int, default=85)
    args = parser.parse_args()
    recompress(args.input, args.output, args.quality)

if __name__ == '__main__':
    main()
