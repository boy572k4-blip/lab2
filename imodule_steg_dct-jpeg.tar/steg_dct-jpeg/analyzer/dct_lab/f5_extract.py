#!/usr/bin/env python3
"""
F5 DCT Steganography - Trích xuất thông điệp từ hệ số AC của khối DCT 8x8 (JPEG)
Phải dùng đúng password và cùng thuật toán với f5_embed.py
"""
import argparse
import numpy as np
from PIL import Image
import hashlib
import struct
import sys


DELIMITER_BITS = [0,1,0,1,1,1,1,1,0,1,0,1,1,1,1,1]  # 16-bit stop marker


def password_to_seed(password: str) -> int:
    h = hashlib.sha256(password.encode()).digest()
    return struct.unpack('>I', h[:4])[0]


def bits_to_text(bits):
    text = ""
    for i in range(0, len(bits) - 7, 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i + j]
        if byte == 0:
            break
        text += chr(byte)
    return text


def get_ac_coefficients(image_path):
    img = Image.open(image_path).convert('YCbCr')
    Y, _, _ = img.split()
    y_array = np.array(Y, dtype=np.float64)
    h, w = y_array.shape

    Q = np.array([
        [2, 2, 2, 2, 3, 4, 5, 6],
        [2, 2, 2, 2, 3, 4, 5, 6],
        [2, 2, 2, 3, 4, 5, 6, 6],
        [2, 2, 3, 4, 5, 6, 6, 6],
        [3, 3, 4, 5, 6, 7, 7, 7],
        [4, 4, 5, 6, 7, 7, 7, 7],
        [5, 5, 6, 6, 7, 7, 7, 7],
        [6, 6, 6, 6, 7, 7, 7, 7],
    ], dtype=np.float64)

    cos_table = np.zeros((8, 8))
    for u in range(8):
        for x in range(8):
            cos_table[u, x] = np.cos((2*x+1)*u*np.pi/16)

    coeffs = []
    num_blocks_x = w // 8
    num_blocks_y = h // 8
    for by in range(num_blocks_y):
        for bx in range(num_blocks_x):
            block = y_array[by*8:(by+1)*8, bx*8:(bx+1)*8] - 128.0
            dct = np.zeros((8, 8))
            for u in range(8):
                for v in range(8):
                    cu = (1/np.sqrt(2)) if u == 0 else 1.0
                    cv = (1/np.sqrt(2)) if v == 0 else 1.0
                    dct[u, v] = 0.25 * cu * cv * np.sum(
                        block * np.outer(cos_table[u], cos_table[v])
                    )
            q_block = np.round(dct / Q).astype(np.int32)
            block_idx = by * num_blocks_x + bx
            for u in range(8):
                for v in range(8):
                    if u == 0 and v == 0:
                        continue
                    coeffs.append([block_idx, u, v, q_block[u, v], by, bx])

    return np.array(coeffs, dtype=object)


def extract_message(input_path, output_path, password):
    print(f"[F5-EXTRACT] Đọc ảnh: {input_path}")
    coeffs = get_ac_coefficients(input_path)

    seed = password_to_seed(password)
    rng = np.random.default_rng(seed)

    nonzero_idx = [i for i, c in enumerate(coeffs) if c[3] != 0]
    perm = rng.permutation(len(nonzero_idx))

    print(f"[INFO] Hệ số AC ≠ 0: {len(nonzero_idx)}")

    extracted_bits = []
    for p in perm:
        idx = nonzero_idx[p]
        bit = int(coeffs[idx][3]) & 1
        extracted_bits.append(bit)

        # Kiểm tra stop marker
        if len(extracted_bits) >= 16:
            tail = extracted_bits[-16:]
            if tail == DELIMITER_BITS:
                message_bits = extracted_bits[:-16]
                message = bits_to_text(message_bits)
                print(f"[SUCCESS] Thông điệp giải mã: '{message}'")
                with open(output_path, 'w') as f:
                    f.write(message + '\n')
                print(f"[INFO] Kết quả lưu vào: {output_path}")
                return message

    print("[WARNING] Không tìm thấy thông điệp ẩn hoặc sai password.")
    with open(output_path, 'w') as f:
        f.write("NOT_FOUND\n")
    sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description='F5 DCT Extract')
    parser.add_argument('--input',    required=True)
    parser.add_argument('--output',   required=True)
    parser.add_argument('--password', required=True)
    args = parser.parse_args()
    extract_message(args.input, args.output, args.password)

if __name__ == '__main__':
    main()
