#!/usr/bin/env python3
"""
F5 DCT Steganography - Nhúng thông điệp vào hệ số AC của khối DCT 8x8 (JPEG)
Thuật toán đơn giản hóa của F5 (Andreas Westfeld, 2001):
  - Dùng PRNG (seed từ password) để chọn các hệ số AC ≠ 0
  - Thay đổi LSB của hệ số AC đã lượng tử hoá
  - Nếu hệ số = 0 sau khi thay LSB → shrinkage (bỏ qua, dùng hệ số tiếp theo)
"""
import argparse
import numpy as np
from PIL import Image
import hashlib
import struct
import os
import io
import sys


DELIMITER_BITS = [0,1,0,1,1,1,1,1,0,1,0,1,1,1,1,1]  # "~~" as stop marker (16 bits)


def password_to_seed(password: str) -> int:
    h = hashlib.sha256(password.encode()).digest()
    return struct.unpack('>I', h[:4])[0]


def text_to_bits(text: str):
    bits = []
    for ch in text:
        b = ord(ch)
        for i in range(7, -1, -1):
            bits.append((b >> i) & 1)
    return bits


def get_jpeg_dct_coefficients(image_path):
    """
    Đọc ảnh JPEG và trả về mảng hệ số DCT đã lượng tử hoá
    sử dụng numpy DCT thủ công trên ảnh đã nén/giải nén.
    Trả về: (y_array, quant_coeffs_flat, img_size)
    """
    img = Image.open(image_path).convert('YCbCr')
    Y, Cb, Cr = img.split()
    y_array = np.array(Y, dtype=np.float64)
    h, w = y_array.shape

    # Bảng lượng tử hoá JPEG chất lượng 95 (xấp xỉ)
    Q = np.array([
        [2, 2, 2, 2, 3, 4, 5, 6],
        [2, 2, 2, 2, 3, 4, 5, 6],
        [2, 2, 2, 3, 4, 5, 6, 6],
        [2, 2, 3, 4, 5, 6, 6, 6],
        [3, 3, 4, 5, 6, 7, 7, 7],
        [4, 4, 5, 6, 7, 7, 7, 7],
        [5, 5, 6, 6, 7, 7, 7, 7],
        [6, 6, 6, 6, 7, 7, 7, 7],
    ], dtype=np.float64)

    cos_table = np.zeros((8, 8))
    for u in range(8):
        for x in range(8):
            cos_table[u, x] = np.cos((2*x+1)*u*np.pi/16)

    coeffs = []  # list of (block_idx, u, v, quant_val)
    num_blocks_y = h // 8
    num_blocks_x = w // 8

    for by in range(num_blocks_y):
        for bx in range(num_blocks_x):
            block = y_array[by*8:(by+1)*8, bx*8:(bx+1)*8] - 128.0
            dct = np.zeros((8, 8))
            for u in range(8):
                for v in range(8):
                    cu = (1/np.sqrt(2)) if u == 0 else 1.0
                    cv = (1/np.sqrt(2)) if v == 0 else 1.0
                    dct[u, v] = 0.25 * cu * cv * np.sum(
                        block * np.outer(cos_table[u], cos_table[v])
                    )
            # Lượng tử hoá
            q_block = np.round(dct / Q).astype(np.int32)
            block_idx = by * num_blocks_x + bx
            for u in range(8):
                for v in range(8):
                    if u == 0 and v == 0:
                        continue  # Bỏ qua DC
                    coeffs.append([block_idx, u, v, q_block[u, v], by, bx])

    return y_array, np.array(coeffs, dtype=object), img.size, Q, cos_table, Cb, Cr


def embed_message(input_path, output_path, message, password):
    print(f"[F5-EMBED] Đọc ảnh: {input_path}")
    y_array, coeffs, img_size, Q, cos_table, Cb, Cr = get_jpeg_dct_coefficients(input_path)
    h, w = y_array.shape

    full_bits = text_to_bits(message) + DELIMITER_BITS
    seed = password_to_seed(password)
    rng = np.random.default_rng(seed)

    # Lọc các hệ số AC ≠ 0 và xáo trộn thứ tự theo seed
    nonzero_idx = [i for i, c in enumerate(coeffs) if c[3] != 0]
    perm = rng.permutation(len(nonzero_idx))

    if len(perm) < len(full_bits):
        print(f"[ERROR] Dung lượng không đủ! Cần {len(full_bits)} bits, chỉ có {len(perm)} hệ số AC ≠ 0")
        sys.exit(1)

    print(f"[INFO] Thông điệp: '{message}' ({len(full_bits)} bits)")
    print(f"[INFO] Hệ số AC ≠ 0 khả dụng: {len(perm)}")

    # Nhúng từng bit vào LSB của hệ số AC
    embed_count = 0
    shrink_count = 0
    ptr = 0
    for i, bit in enumerate(full_bits):
        while ptr < len(perm):
            idx = nonzero_idx[perm[ptr]]
            ptr += 1
            old_val = int(coeffs[idx][3])
            new_val = (old_val & ~1) | bit
            if new_val == 0:
                # Shrinkage: hệ số trở thành 0 → F5 bỏ qua, dùng hệ số tiếp theo
                shrink_count += 1
                continue
            coeffs[idx][3] = new_val
            embed_count += 1
            break

    print(f"[INFO] Đã nhúng: {embed_count} bits | Shrinkage: {shrink_count}")

    # Tái tạo ảnh từ các hệ số đã sửa
    Q_arr = Q
    num_blocks_x = w // 8
    num_blocks_y = h // 8

    # Xây dựng lại mảng DCT lượng tử hoá cho kênh Y
    q_blocks = {}
    for c in coeffs:
        bkey = (int(c[4]), int(c[5]))
        if bkey not in q_blocks:
            q_blocks[bkey] = np.zeros((8, 8), dtype=np.int32)
        q_blocks[bkey][int(c[1]), int(c[2])] = int(c[3])

    # Lấy lại DC từ ảnh gốc
    img_orig = Image.open(input_path).convert('YCbCr')
    Y_orig, _, _ = img_orig.split()
    y_orig = np.array(Y_orig, dtype=np.float64)

    cos_inv = np.zeros((8, 8))
    for x in range(8):
        for u in range(8):
            cu = (1/np.sqrt(2)) if u == 0 else 1.0
            cos_inv[x, u] = cu * np.cos((2*x+1)*u*np.pi/16)

    new_y = np.zeros_like(y_orig)
    for by in range(num_blocks_y):
        for bx in range(num_blocks_x):
            bkey = (by, bx)
            q_block = q_blocks.get(bkey, np.zeros((8, 8), dtype=np.int32))
            # Tính DC từ block gốc
            block_orig = y_orig[by*8:(by+1)*8, bx*8:(bx+1)*8] - 128.0
            dc_val = 0.25 * (1/np.sqrt(2)) * (1/np.sqrt(2)) * np.sum(
                block_orig * np.outer(cos_table[0], cos_table[0])
            )
            q_block[0, 0] = int(np.round(dc_val / Q_arr[0, 0]))

            # Giải lượng tử hoá
            dct_block = q_block.astype(np.float64) * Q_arr

            # IDCT
            reconstructed = np.zeros((8, 8))
            for x in range(8):
                for y in range(8):
                    s = 0.0
                    for u in range(8):
                        for v in range(8):
                            cu = (1/np.sqrt(2)) if u == 0 else 1.0
                            cv = (1/np.sqrt(2)) if v == 0 else 1.0
                            s += cu * cv * dct_block[u, v] * \
                                 np.cos((2*x+1)*u*np.pi/16) * \
                                 np.cos((2*y+1)*v*np.pi/16)
            reconstructed[x, y] = 0.25 * s
            reconstructed = np.clip(reconstructed + 128.0, 0, 255)
            new_y[by*8:(by+1)*8, bx*8:(bx+1)*8] = reconstructed

    Y_new = Image.fromarray(new_y.astype(np.uint8), 'L')
    stego = Image.merge('YCbCr', (Y_new, Cb, Cr)).convert('RGB')
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    stego.save(output_path, 'JPEG', quality=95)
    print(f"[SUCCESS] Stego image đã lưu: {output_path}")
    print(f"[INFO] Thông điệp đã nhúng: '{message}'")


def main():
    parser = argparse.ArgumentParser(description='F5 DCT Embed')
    parser.add_argument('--input',    required=True)
    parser.add_argument('--output',   required=True)
    parser.add_argument('--message',  required=True)
    parser.add_argument('--password', required=True)
    args = parser.parse_args()
    embed_message(args.input, args.output, args.message, args.password)

if __name__ == '__main__':
    main()
