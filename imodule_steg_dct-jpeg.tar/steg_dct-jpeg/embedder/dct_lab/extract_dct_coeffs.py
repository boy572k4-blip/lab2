#!/usr/bin/env python3
"""Trích xuất và hiển thị hệ số DCT của ảnh JPEG"""
import argparse
import numpy as np
from PIL import Image

def extract_dct_block(image_path, block_index=0):
    img = Image.open(image_path).convert('YCbCr')
    Y, _, _ = img.split()
    y_array = np.array(Y, dtype=np.float64)

    height, width = y_array.shape
    blocks_per_row = width // 8
    block_row = block_index // blocks_per_row
    block_col = block_index % blocks_per_row

    y_start = block_row * 8
    x_start = block_col * 8
    block = y_array[y_start:y_start+8, x_start:x_start+8] - 128.0

    # DCT-II thủ công (giống JPEG)
    dct_block = np.zeros((8, 8), dtype=np.float64)
    for u in range(8):
        for v in range(8):
            cu = (1/np.sqrt(2)) if u == 0 else 1.0
            cv = (1/np.sqrt(2)) if v == 0 else 1.0
            s = 0.0
            for x in range(8):
                for y in range(8):
                    s += block[x, y] * \
                         np.cos((2*x+1)*u*np.pi/16) * \
                         np.cos((2*y+1)*v*np.pi/16)
            dct_block[u, v] = 0.25 * cu * cv * s

    print(f"\n[INFO] Ảnh: {image_path}")
    print(f"[INFO] Block #{block_index} tại vị trí pixel ({x_start},{y_start})")
    print(f"\n--- Ma trận DCT 8x8 (kênh Y) ---")
    for row in dct_block:
        print("  " + "  ".join(f"{v:8.2f}" for v in row))

    ac_0_1 = dct_block[0, 1]
    print(f"\n[RESULT] Hệ số AC tại (0,1): {ac_0_1:.4f}")
    print(f"[RESULT] Hệ số DC tại (0,0): {dct_block[0,0]:.4f}")
    return ac_0_1

def main():
    parser = argparse.ArgumentParser(description='Trích xuất hệ số DCT từ ảnh JPEG')
    parser.add_argument('--image', required=True, help='Đường dẫn ảnh JPEG')
    parser.add_argument('--block', type=int, default=0, help='Chỉ số block 8x8 (mặc định: 0)')
    args = parser.parse_args()
    extract_dct_block(args.image, args.block)

if __name__ == '__main__':
    main()
