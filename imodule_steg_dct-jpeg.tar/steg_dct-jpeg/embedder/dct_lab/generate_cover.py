#!/usr/bin/env python3
"""Tạo ảnh cover.jpg cho bài lab DCT steganography"""
from PIL import Image
import random, math, os

STEG_DIR = '/home/ubuntu/dct_lab'
random.seed(2024)
width, height = 512, 512
img = Image.new('RGB', (width, height))
pixels = []
for y in range(height):
    for x in range(width):
        r = int(128 + 90 * math.sin(x * 0.04) + random.randint(-8, 8))
        g = int(128 + 90 * math.cos(y * 0.04) + random.randint(-8, 8))
        b = int(128 + 70 * math.sin((x + y) * 0.025) + random.randint(-8, 8))
        pixels.append((max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b))))
img.putdata(pixels)
os.makedirs(STEG_DIR, exist_ok=True)
out = os.path.join(STEG_DIR, 'cover.jpg')
img.save(out, 'JPEG', quality=95)
print(f"[OK] cover.jpg: {width}x{height} pixels -> {out}")
