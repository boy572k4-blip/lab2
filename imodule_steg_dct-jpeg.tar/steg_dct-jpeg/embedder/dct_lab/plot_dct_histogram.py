#!/usr/bin/env python3
"""
Vẽ histogram phân phối hệ số DCT của ảnh cover và stego để phát hiện bất thường.
Phân tích cặp (2k, 2k+1) để tìm bất đối xứng do LSB embedding.
"""
import argparse
import numpy as np
from PIL import Image
import os

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False


def get_ac_coefficients(image_path):
    img = Image.open(image_path).convert('YCbCr')
    Y, _, _ = img.split()
    y_array = np.array(Y, dtype=np.float64)
    h, w = y_array.shape

    Q = np.array([
        [2, 2, 2, 2, 3, 4, 5, 6],
        [2, 2, 2, 2, 3, 4, 5, 6],
        [2, 2, 2, 3, 4, 5, 6, 6],
        [2, 2, 3, 4, 5, 6, 6, 6],
        [3, 3, 4, 5, 6, 7, 7, 7],
        [4, 4, 5, 6, 7, 7, 7, 7],
        [5, 5, 6, 6, 7, 7, 7, 7],
        [6, 6, 6, 6, 7, 7, 7, 7],
    ], dtype=np.float64)

    ac_vals = []
    cos_table = np.zeros((8, 8))
    for u in range(8):
        for x in range(8):
            cos_table[u, x] = np.cos((2*x+1)*u*np.pi/16)

    for by in range(h // 8):
        for bx in range(w // 8):
            block = y_array[by*8:(by+1)*8, bx*8:(bx+1)*8] - 128.0
            dct = np.zeros((8, 8))
            for u in range(8):
                for v in range(8):
                    cu = (1/np.sqrt(2)) if u == 0 else 1.0
                    cv = (1/np.sqrt(2)) if v == 0 else 1.0
                    dct[u, v] = 0.25 * cu * cv * np.sum(
                        block * np.outer(cos_table[u], cos_table[v])
                    )
            q_block = np.round(dct / Q).astype(np.int32)
            for u in range(8):
                for v in range(8):
                    if u == 0 and v == 0:
                        continue  # Bỏ qua DC
                    ac_vals.append(q_block[u, v])
    return np.array(ac_vals)


def analyze_asymmetry(ac_vals, label):
    """Phân tích bất đối xứng cặp (2k, 2k+1)"""
    hist, edges = np.histogram(ac_vals, bins=range(-30, 31))
    bin_vals = edges[:-1]

    max_asym = 0
    max_asym_val = 0
    for k in range(-15, 15):
        idx_even = np.where(bin_vals == 2*k)[0]
        idx_odd  = np.where(bin_vals == 2*k+1)[0]
        if len(idx_even) > 0 and len(idx_odd) > 0:
            asym = abs(int(hist[idx_even[0]]) - int(hist[idx_odd[0]]))
            if asym > max_asym:
                max_asym = asym
                max_asym_val = 2*k

    print(f"\n[{label}] Bất đối xứng lớn nhất tại hệ số DCT = {max_asym_val} (chênh lệch = {max_asym})")
    return hist, bin_vals, max_asym_val


def plot_histogram(cover_path, stego_path, output_path):
    print(f"[HISTOGRAM] Phân tích: {cover_path} vs {stego_path}")
    cover_ac = get_ac_coefficients(cover_path)
    stego_ac = get_ac_coefficients(stego_path)

    cover_hist, cover_bins, cover_asym = analyze_asymmetry(cover_ac, "COVER")
    stego_hist, stego_bins, stego_asym = analyze_asymmetry(stego_ac, "STEGO")

    print(f"\n[SUMMARY] Bất đối xứng rõ nhất trong ảnh stego tại hệ số DCT = {stego_asym}")

    if HAS_MATPLOTLIB:
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        axes[0].bar(cover_bins, cover_hist, color='steelblue', alpha=0.8, width=0.8)
        axes[0].set_title('Cover Image - DCT AC Coefficient Histogram')
        axes[0].set_xlabel('Giá trị hệ số DCT lượng tử hoá')
        axes[0].set_ylabel('Tần suất')
        axes[0].set_xlim(-20, 20)
        axes[0].axvline(x=cover_asym, color='red', linestyle='--', label=f'Bất đối xứng tại {cover_asym}')
        axes[0].legend()

        axes[1].bar(stego_bins, stego_hist, color='tomato', alpha=0.8, width=0.8)
        axes[1].set_title('Stego Image - DCT AC Coefficient Histogram')
        axes[1].set_xlabel('Giá trị hệ số DCT lượng tử hoá')
        axes[1].set_ylabel('Tần suất')
        axes[1].set_xlim(-20, 20)
        axes[1].axvline(x=stego_asym, color='darkred', linestyle='--', label=f'Bất đối xứng tại {stego_asym}')
        axes[1].legend()

        plt.tight_layout()
        plt.savefig(output_path, dpi=120)
        print(f"[OK] Histogram đã lưu: {output_path}")
    else:
        print("[WARN] matplotlib không khả dụng. Chỉ hiển thị phân tích text.")
        print(f"  Giá trị hệ số có bất đối xứng rõ nhất (stego): {stego_asym}")


def main():
    parser = argparse.ArgumentParser(description='Vẽ histogram DCT coefficient')
    parser.add_argument('--cover',  required=True)
    parser.add_argument('--stego',  required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    plot_histogram(args.cover, args.stego, args.output)

if __name__ == '__main__':
    main()
