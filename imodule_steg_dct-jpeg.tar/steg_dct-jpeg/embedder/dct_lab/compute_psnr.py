#!/usr/bin/env python3
"""Tính chỉ số PSNR giữa ảnh gốc và ảnh stego"""
import argparse
import numpy as np
from PIL import Image


def compute_psnr(original_path, stego_path):
    orig = Image.open(original_path).convert('RGB')
    stego = Image.open(stego_path).convert('RGB')

    if orig.size != stego.size:
        print(f"[ERROR] Kích thước ảnh khác nhau: {orig.size} vs {stego.size}")
        return

    orig_arr  = np.array(orig,  dtype=np.float64)
    stego_arr = np.array(stego, dtype=np.float64)

    mse = np.mean((orig_arr - stego_arr) ** 2)
    if mse == 0:
        print("[RESULT] PSNR = ∞ dB (ảnh hoàn toàn giống nhau)")
        return float('inf')

    psnr = 10 * np.log10((255.0 ** 2) / mse)

    print(f"\n[PSNR ANALYSIS]")
    print(f"  Ảnh gốc  : {original_path}")
    print(f"  Ảnh stego: {stego_path}")
    print(f"  MSE      : {mse:.6f}")
    print(f"  PSNR     : {psnr:.4f} dB")

    if psnr > 40:
        print("  [OK] PSNR > 40 dB → ảnh stego gần như không phân biệt được với ảnh gốc.")
    else:
        print("  [WARN] PSNR <= 40 dB → có thể phát hiện được bằng mắt thường.")

    return psnr


def main():
    parser = argparse.ArgumentParser(description='Tính PSNR giữa ảnh gốc và stego')
    parser.add_argument('--original', required=True)
    parser.add_argument('--stego',    required=True)
    args = parser.parse_args()
    compute_psnr(args.original, args.stego)

if __name__ == '__main__':
    main()
