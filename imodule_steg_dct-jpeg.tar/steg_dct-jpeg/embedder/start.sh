#!/bin/bash
service ssh start 2>/dev/null

# Tạo .seed cho Labtainer grader
mkdir -p /home/ubuntu/.local
echo "steg_dct-jpeg_seed" > /home/ubuntu/.local/.seed
echo "student@labtainer.local" > /home/ubuntu/.local/.email
echo "steg_dct-jpeg" > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

# Tạo /var/labtainer/did_param
mkdir -p /var/labtainer
touch /var/labtainer/did_param

# Tạo cover image nếu chưa có
mkdir -p /home/ubuntu/dct_lab
chown -R ubuntu:ubuntu /home/ubuntu/dct_lab
if [ ! -f /home/ubuntu/dct_lab/cover.jpg ]; then
    python3 /home/ubuntu/dct_lab/generate_cover.py 2>/dev/null
    chown ubuntu:ubuntu /home/ubuntu/dct_lab/cover.jpg 2>/dev/null
fi

tail -f /dev/null
